﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AllQue
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // Initialize the Calendar control.
                Calendar1.SelectedDate = DateTime.Today;
            }
        }     
        protected void Calendar1_SelectionChanged1(object sender, EventArgs e)
        {
            DateTime selectedDate = Calendar1.SelectedDate;
            DateTime today = DateTime.Today;

            // Calculate the difference in days between selectedDate and today.
            TimeSpan difference = selectedDate - today;
            int daysDifference = (int)difference.TotalDays;

            // Display a message in the Label control.
            //MessageLabel.Text = $"Selected Date: {selectedDate.ToShortDateString()} ({daysDifference} days from today)";

            MessageLabel.Text = "Selected Date: " + selectedDate.ToShortDateString() + " (" + daysDifference + " days from today)";

        }       

    }
}