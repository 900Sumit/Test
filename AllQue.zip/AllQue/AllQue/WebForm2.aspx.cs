﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AllQue
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // Initialize the radio buttons and set their AutoPostBack property to true.
                RadioGroup1.Checked = false;
                RadioGroup2.Checked = false;
                RadioGroup1.AutoPostBack = true;
                RadioGroup2.AutoPostBack = true;
            }
        }

        protected void Radio_CheckedChanged(object sender, EventArgs e)
        {
            // Handle radio button selection change event.
            RadioButton radioButton = (RadioButton)sender;
            Label labelToUpdate = null;

            // Determine which label to update based on the radio button's group.
            if (radioButton.GroupName == "Group1")
            {
                labelToUpdate = LabelGroup1;
            }
            else if (radioButton.GroupName == "Group2")
            {
                labelToUpdate = LabelGroup2;
            }

            // Update the label's font size and color.
            if (labelToUpdate != null)
            {
                labelToUpdate.Font.Size = new FontUnit("56px"); // Change the font size.
                labelToUpdate.ForeColor = System.Drawing.Color.Blue; // Change the font color.
            }
        }

        protected void CountryDropdown_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Handle dropdown list selection change event.
        if (CountryDropdown.SelectedValue == "1")
        {
            CountryCodeTextBox.Text = "+91"; // INDIA country code.
        }
        else if (CountryDropdown.SelectedValue == "2")
        {
            CountryCodeTextBox.Text = "+2"; // Canada country code.
        }
        else if (CountryDropdown.SelectedValue == "3")
        {
            CountryCodeTextBox.Text = "+3"; // UK country code.
        }
        else if (CountryDropdown.SelectedValue == "4")
        {
            CountryCodeTextBox.Text = "+1"; // USA country code.
        }
        else
        {
            CountryCodeTextBox.Text = ""; // Clear the textbox if no country is selected.
        }
    
        }

        protected void FontRadioButton_CheckedChanged(object sender, EventArgs e)
        {
            RadioButton radioButton = (RadioButton)sender;
            Label labelToUpdate = null;

            // Determine which label to update based on the radio button's group.
            if (radioButton.GroupName == "Group1")
            {
                labelToUpdate = LabelGroup1;
            }
            else if (radioButton.GroupName == "Group2")
            {
                labelToUpdate = LabelGroup2;
            }

            // Update the label's font family.
            if (labelToUpdate != null)
            {
                if (FontArial.Checked)
                {
                    labelToUpdate.Font.Name = "Arial";
                }
                else if (FontTimesNewRoman.Checked)
                {
                    labelToUpdate.Font.Name = "Times New Roman";
                }
                else if (FontVerdana.Checked)
                {
                    labelToUpdate.Font.Name = "Verdana";
                }
            }
        }
    }
}